import os
import sys
from bs4 import BeautifulSoup

def sort_dict(d):
    return {k: v for k, v in sorted(d.items(), key=lambda i: i[1], reverse=True)}

def main(folder_name="pagev2"):
   users = set()
   total_messages = {}
   montcuq_occurences = {}
   less_than_30 = {}
   folders_whitelist = {"65183157", "65202622", "65164921"}
   mes_in_whitelist = {}
   path = os.path.join(folder_name, "pages")
   for root, dirs, files in os.walk(path):
       for thread_dir in dirs:
           sub_path = os.path.join(path, thread_dir)
           for r, ds, fs in os.walk(sub_path):
               for f in fs:
                   if f.endswith(".html"):
                       with open(os.path.join(sub_path, f), 'r') as html:
                           soup = BeautifulSoup(html, 'html.parser')
                           for post in soup.find_all("div", class_="tid_post"):
                               author = post.find("div", class_="tid_name").text
                               content = post.find("div", class_="tid_editorContent").text
                               #print(content)
                               users.add(author)
                               if author not in total_messages:
                                   total_messages[author] = 1
                               else:
                                   total_messages[author] += 1
                               if author not in montcuq_occurences:
                                   montcuq_occurences[author] = 0
                               montcuq_occurences[author] += content.lower().count('montcuq')
                               if author not in less_than_30:
                                   less_than_30[author] = 0
                               if len(content) < 30:
                                   less_than_30[author] += 1
                               if author not in mes_in_whitelist:
                                   mes_in_whitelist[author] = 0
                               if thread_dir in folders_whitelist:
                                   mes_in_whitelist[author] += 1

   print(users)
   print(len(users))
   print(len(total_messages))
   sorted_msgs = {k: v for k, v in sorted(total_messages.items(), key=lambda item: item[1], reverse=True)}
   sorted_montcuq = {k: v for k, v in sorted(montcuq_occurences.items(), key=lambda item: item[1], reverse=True)}
   sorted_less_than_30 = sort_dict(less_than_30)
   sorted_in_whitelist = sort_dict(mes_in_whitelist)
   for name, n in sorted_msgs.items():
       print(name, ":", n, "messages")
   print("\n\nMontcuq Leaderboard")
   for name, n in sorted_montcuq.items():
       print(name, ":", n, "occurences de Montcuq")
   print("\n\nPetit texte")
   for name, n in sorted_less_than_30.items():
       print(name, ":", n, "messages de moins de 30 caractères, {:.1f}% de ses messages".format(round(n/total_messages[name] * 100, 2)))

   print("\n\nParticipation Comm")
   for name, n in sorted_in_whitelist.items():
        print(name, ":", n, "messages de comm ({:.1f}% de ses messages)".format(round(n/total_messages[name] * 100, 2)))
                           

if __name__ == "__main__":
    if len(sys.argv) == 2:
        main(sys.argv[1])
    else:
        main()
