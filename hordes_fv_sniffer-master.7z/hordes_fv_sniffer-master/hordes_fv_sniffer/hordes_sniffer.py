#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Copyright © 03/28/2018, EngelOfChipo

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

The Software is provided “as is”, without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose and noninfringement. In no event shall the authors or copyright holders X be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection with the software or the use or other dealings in the Software.
Except as contained in this notice, the name of the EngelOfChipo shall not be used in advertising or otherwise to promote the sale, use or other dealings in this Software without prior written authorization from the EngelOfChipo.
"""

from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.common.exceptions import NoSuchElementException
import codecs
import os
from time import sleep
import re
import sys
from collections import namedtuple
from datetime import datetime
import pytz
import getpass
import re
import shutil


TThread = namedtuple("TThread", ['thread_id', 'page_count', 'thread_page_number', 'folder_name', 'title'])

CITY_ID_REGEX = re.compile("/tid/forum#!view/(\d+)")

threads = []
first_thread_of_page = {}

page_number = 0
#ff_profile_path = "/home/gbuisan/.mozilla/firefox/narkp3dy.selenium"


BASE_URL = "http://www.hordes.fr/tid/forum"
THREAD_PAGE_URL = "http://www.hordes.fr/tid/forum#!view/{city_id}?p={thread_list_page}"
THREAD_URL = "http://www.hordes.fr/tid/forum#!view/{city_id}?p={thread_list_page}|thread/{thread_id}?p={thread_page}"

first_post_of_page = {}

city_id = 0


def handle_connexion(driver, email, password):
    print("You are not connected !")
    login_button = driver.find_elements_by_class_name("tid_login")
    if len(login_button) != 1:
        driver.close()
        raise AssertionError("Login Button not found (or multiple)" + str(len(login_button)))
    login_button = login_button[0]
    login_button.click()
    driver.switch_to.frame("tid_login")
    if email is None and password is None:
        email = input("Email").strip()
        password = getpass.getpass("Password", ).strip()
    email_field = None
    pass_field = None
    keep_session_check = None
    submit_button = None
    while email_field is None and pass_field is None and keep_session_check is None and submit_button is None:
        try:
            email_field = driver.find_element_by_name("login")
            pass_field = driver.find_element_by_name("pass")
            keep_session_check = driver.find_element_by_name("keepSession")
            submit_button = driver.find_element_by_name("submit")
        except NoSuchElementException as e:
            sleep(0.5)

    email_field.clear()
    email_field.send_keys(email)
    pass_field.clear()
    pass_field.send_keys(password)
    if not keep_session_check.is_selected():
        keep_session_check.click()
    submit_button.click()
    driver.switch_to.default_content()


def get_pages_count(elt):
    tid_count = elt.find("div", {"class": "tid_count"})
    if tid_count is None:
        driver.close()
        raise AssertionError("No tid_count div found for :" + e)
    message_count = tid_count.getText().strip()
    if message_count == "":
        message_count = 1
    else:
        message_count = int(message_count) + 1
    return int((message_count - 1) / 10 + 1)


def get_thread_title(elt):
    title_a = elt.findAll("a")
    if len(title_a) != 1:
        driver.close()
        raise AssertionError("More than one 'a' found for the thread title" + e)
    title_a = title_a[0]
    title = ""
    titles = title_a.findAll(text=True)
    for t in titles:
        if t.strip() != "":
            title += t.strip() + " "
    return title[:-1]


def fill_city_id(url):
    global city_id
    print(url)
    if city_id == 0:
        cid = CITY_ID_REGEX.search(url)
        city_id = int(cid.group(1))


def fix_left_navigation_arrows_links(soup, current_page):
    global first_thread_of_page

    left_part = soup.findAll("td", {"id": "tid_forum_left"}, recursive=True)
    assert (len(left_part) == 1)
    left_part = left_part[0]
    first_arrow = left_part.findAll("a", {"title": "Première page"}, recursive=True)
    if len(first_arrow) > 0:
        for arr in first_arrow:
            arr['href'] = "../{}/1.html".format(first_thread_of_page[1])

    previous_arrow = left_part.findAll("a", {"title": "Page précédente"}, recursive=True)
    if len(previous_arrow) > 0:
        for arr in previous_arrow:
            arr['href'] = "../{}/1.html".format(first_thread_of_page[current_page - 1])

    next_arrow = left_part.findAll("a", {"title": "Page suivante"}, recursive=True)
    if len(next_arrow) > 0:
        for arr in next_arrow:
            arr['href'] = "../{}/1.html".format(first_thread_of_page[current_page + 1])

    last_arrow = left_part.findAll("a", {"title": "Dernière page"}, recursive=True)
    if len(last_arrow) > 0:
        last_page_topic = first_thread_of_page[max(first_thread_of_page.keys())]
        for arr in last_arrow:
            arr['href'] = "../{}/1.html".format(last_page_topic)

def fix_right_navigation_arrows_links(soup, current_page, max_page):
    right_part = soup.findAll("td", {"id": "tid_forum_right"}, recursive=True)
    assert(len(right_part) == 1)
    right_part = right_part[0]

    first_arrow = right_part.findAll("a", {"title": "Première page"}, recursive=True)
    if len(first_arrow) > 0:
        for arr in first_arrow:
            arr['href'] = "./1.html"

    prev_arrow = right_part.findAll("a", {"title": "Page précédente"}, recursive=True)
    if len(prev_arrow) > 0:
        for arr in prev_arrow:
            arr['href'] = "./{}.html".format(current_page - 1)

    next_arrow = right_part.findAll("a", {"title": "Page suivante"}, recursive=True)
    if len(next_arrow) > 0:
        for arr in next_arrow:
            arr['href'] = "./{}.html".format(current_page + 1)

    last_arrow = right_part.findAll("a", {"title": "Dernière page"}, recursive=True)
    if len(last_arrow) > 0:
        for arr in last_arrow:
            arr['href'] = "./{}.html".format(max_page)


def main(login_mail=None, login_password=None, folder_name=None, status=None):
    global threads
    global first_thread_of_page
    global ff_profile_path
    global BASE_URL
    global THREAD_PAGE_URL
    global THREAD_URL
    global city_id

    if folder_name is None:
        folder_name = "pagev2"

    ff_options = Options()
    ff_options.set_headless(True)  # newer webdriver versions
    #profile = webdriver.FirefoxProfile(ff_profile_path)
    #driver = webdriver.Firefox(profile, options=ff_options)
    driver = webdriver.Firefox(options=ff_options)
    #driver = webdriver.Remote(desired_capabilities=webdriver.DesiredCapabilities.HTMLUNITWITHJS)

    driver.get(BASE_URL)
    print(driver.title)

    elt = None

    while elt is None:
        try:
            elt = driver.find_element_by_id("main2")
            if elt is not None:
                print("You are connected !")
        except NoSuchElementException as e:
            try:
                elt = driver.find_element_by_id("main3")
                if elt is not None:
                    if status is not None:
                        status["step"] = 1
                        status["finished"] = False
                        status["desc"] = "Identification"
                    handle_connexion(driver, login_mail, login_password)

            except NoSuchElementException as e:
                sleep(0.5)
    elt = None

    loading = True
    while loading:
        try:
            elts = driver.find_elements_by_class_name("tid_forumThreads")
            if len(elts) > 0:
                loading = False
            sleep(0.5)
            print("Loading...")
        except NoSuchElementException:
            sleep(0.5)

    if status is not None:
        status["step"] = 1
        status["finished"] = False
        status["desc"] = "Récupération de l'id de la ville"

    fill_city_id(driver.current_url)

    if status is not None:
        status["step"] = 2
        status["finished"] = False
        status["desc"] = "Récupération du nombre de pages de topic"

    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")

    thread_container = soup.findAll("div", {"class": "tid_forumThreads"})
    if len(thread_container) != 1:
        raise AssertionError("Multiple thread container found")
    thread_container = thread_container[0]
    thread_list_pages = thread_container.findAll("span", {"class": "tid_pageTotal"})
    tries = 0
    while len(thread_list_pages) == 0:
        thread_list_pages = thread_container.findAll("span", {"class": "tid_pageTotal"})
        sleep(0.5)
        tries += 1
        if tries >= 10:
            break
    if len(thread_list_pages) == 0:
        thread_list_pages = 1
    else:
        thread_list_pages = int(thread_list_pages[0].getText().replace("/", " ").strip())

    save_start_time = datetime.now()

    # Go through all thread pages

    for thread_list_p in range(1, thread_list_pages + 1):
        if status is not None:
            status["step"] = 3
            status["finished"] = False
            status["desc"] = "Récupération des id des topics"
            status["progress1title"] = "page"
            status["progress1"] = thread_list_p
            status["total1"] = thread_list_pages
        driver.get(THREAD_PAGE_URL.format(city_id=city_id, thread_list_page=thread_list_p))
        loading = True
        tries = 0
        while loading:
            try:
                elts = driver.find_elements_by_class_name("tid_pageNumber")
                tries += 1
                if (len(elts) == 1 and int(elts[0].text) == thread_list_p) or tries >= 10:
                    loading = False                
                sleep(0.5)
            except NoSuchElementException:
                sleep(0.5)

        html = driver.page_source
        soup = BeautifulSoup(html, "html.parser")


        thread_table = soup.findAll("table", {"class": "tid_threads"})
        while len(thread_table) == 0:
            thread_table = soup.findAll("table", {"class": "tid_threads"})
            sleep(0.5)
        if len(thread_table) != 1:
            #driver.close()
            raise AssertionError("Something went wrong... multiple thread table found." + str(len(thread_table)))
        thread_table = thread_table[0]

        for e in thread_table.findAll("tr", recursive=True):
            thrid = e.get('id')
            if thrid is not None and "tid_forumThread_" in thrid:
                thread_id = int(thrid.strip("tid_forumThread_"))
                pages_count = get_pages_count(e)
                title = get_thread_title(e)

                if thread_list_p not in first_thread_of_page:
                    first_thread_of_page[thread_list_p] = thread_id

                # for t in title_a.findAll():
                #     title += t.getText().strip() + " "
                # title += title[:-1]
                threads.append(TThread(thread_id, pages_count, thread_list_p, title, title))

    print("Found : ", len(threads), "forum threads")

    for j, t in enumerate(threads):
        #print("Saving thread : ", t.thread_id)
        folder = os.path.join(folder_name, "pages", str(t.thread_id))
        if not os.path.exists(folder):
            os.makedirs(folder)
        for i in range(1, t.page_count + 1):
            if status is not None:
                status["step"] = 4
                status["finished"] = False
                status["desc"] = "Sauvegarde des topics"
                status["progress1title"] = "topic"
                status["progress1"] = j
                status["total1"] = len(threads)
                status["progress2title"] = "page"
                status["progress2"] = i
                status["total2"] = t.page_count
            print("\r", j + 1, "/", len(threads), "\tSaving thread: ", str(t.thread_id), "  page: ",  i, "/", t.page_count, "\033[K", end="")
            driver.get(THREAD_URL.format(city_id=city_id, thread_list_page=t.thread_page_number, thread_id=t.thread_id, thread_page=i))
            loading = True
            while loading:
                try:
                    elts = driver.find_elements_by_class_name("tid_loading")
                    sleep(0.05)
                    if len(elts) == 0:
                        loading = False
                    #print("Loading...")
                except NoSuchElementException:
                    loading = False

            thread_soup = BeautifulSoup(driver.page_source, "html.parser")
            wrapping_html = BeautifulSoup(
                '''<html><head><meta charset="UTF-8">
                <title>FV</title><link rel="stylesheet" type="text/css" href="../../css/hordes.css">
                <link rel="stylesheet" type="text/css" href="../../css/bar.css">
                <link rel="stylesheet" type="text/css" href="../../css/custom.css"></head>
                <body><div id="contentBg"></div></body></html>''', "html.parser")
            to_save = thread_soup.find('div', attrs={"class":u"tid_forum_init"})
            # Inter threads links
            for a in to_save.findAll("a", {"class": u"tid_subject tid_border1 tid_bg1"}, recursive=True):  # Posit-it threads
                th_n = a['href'].split("/")[-1].strip()
                a['href'] = "../{}/1.html".format(th_n)
            for a in to_save.findAll("a", {"class": u"tid_subject tid_border3 tid_bg3"}, recursive=True):  # Classic threads
                th_n = a['href'].split("/")[-1].strip()
                a['href'] = "../{}/1.html".format(th_n)

            # Twinoid data and images
            for img in to_save.findAll("img", recursive=True):
                if "http://" not in img['src'] and "https://" not in img['src']:
                    img['src'] = img['src'].replace("//data", "http://data")
                    img['src'] = img['src'].replace("//imgup", "https://imgup")

            # Thread pages navigation
            if thread_list_pages > 1:
                fix_left_navigation_arrows_links(to_save, t.thread_page_number)

            # Pages navigation inside thread
            if t.page_count > 1:
                fix_right_navigation_arrows_links(to_save, i, t.page_count)

            wrapping_html.div.insert(1, to_save)
            footer = BeautifulSoup('''<div class="custom_footer">Outil créé par <a href="http://www.hordes.fr/#ghost/city?go=ghost/user?uid=601525">EngelOfChipo</a> | Sauvegarde du {}'''.format(save_start_time.strftime("%d/%m/%Y, %H:%M:%S")), features="html.parser")
            wrapping_html.body.append(footer)
            with open(os.path.join(folder, str(i) + ".html"), 'wb') as f:
                f.write(wrapping_html.encode('utf-8'))
    driver.close()
    shutil.copytree(os.path.join(os.path.dirname(os.path.abspath(__file__)), "css"), os.path.join(folder_name, "css"))
    index = BeautifulSoup(
                '''<head> 
                    <meta http-equiv="refresh" content="0; URL=./pages/{}/1.html" />
                </head>
                '''.format(first_thread_of_page[1]), "html.parser")
    with open(os.path.join(folder_name, "index.html"), 'wb') as f:
        f.write(index.encode('utf-8'))
    shutil.make_archive(folder_name, 'zip', folder_name)
    if status is not None:
        status["step"] = 5
        status["finished"] = True
        status["filename"] = "{}.zip".format(folder_name)
    return "{}.zip".format(folder_name)


if __name__== "__main__":
    main()