(function worker() {
  let isfinished = false;
  $.ajax({
    url: './status',
    success: function(data) {
      if ("finished" in data && data["finished"]){
        isfinished = true;
        document.location.reload();
      }else{
        if ("step" in data){
          $("#step").html(data["step"])
        }
        if ("desc" in data){
          $("#desc").html(data["desc"])
        }
        if ("progress1title" in data && "progress1" in data && "total1" in data){
          $("#progress1title").html(data["progress1title"]).show();
          $("#progress1").attr(    {'value': data["progress1"], 'max': data["total1"]}).show()
              .html(data["progress1"] + "/" + data["total1"] + "(" + data["progress1"]/data["total1"]*100 + "%)");
        }
        if ("progress2title" in data && "progress2" in data && "total2" in data){
          $("#progress2title").html(data["progress2title"]).show();
          $("#progress2").attr(    {'value': data["progress2"], 'max': data["total2"]}).show()
              .html(data["progress2"] + "/" + data["total2"] + "(" + data["progress2"]/data["total2"]*100 + "%)");
        }
      }
      console.log(data)
    },
    complete: function() {
      // Schedule the next request when the current one's complete
      if (!isfinished) {
        setTimeout(worker, 1000);
      }
    }
  });
})();