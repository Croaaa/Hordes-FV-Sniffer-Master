from flask import Flask, request, url_for, redirect, g, render_template, session, jsonify, send_file, Blueprint
from flask_executor import Executor
import os
import uuid
from time import sleep
from hordes_fv_sniffer.hordes_sniffer import main as hs_main

bp = Blueprint("hordes_fv_sniffer", __name__, template_folder="templates", static_folder="static")

def create_app(test_config=None):
    bp.params = {}
    

    @bp.route('/')
    def index():
        #return app.config["APPLICATION_ROOT"]
        return render_template("index.html", save_url=url_for("hordes_fv_sniffer.save"), css_url=url_for("hordes_fv_sniffer.static", filename="css/main.css"))

    
    @bp.route('/save', methods=['GET', 'POST'])
    def save():

        #if request.method == 'POST':
            #hordes_fv_sniffer.hordes_fv_sniffer.main("engelofdeath@live.fr")
        task_id = uuid.uuid4()
        session["id"] = task_id
        bp.params[task_id] = {"status": "Chargement..."}
        login = request.form['email']
        password = request.form['password']
        executor.submit_stored(task_id, hs_main, login, password, os.path.join("flaskr", "archives", str(task_id)), bp.params[task_id])
        #mock_test_func.submit_stored("test", "plop", "plup")
        return redirect(url_for("hordes_fv_sniffer.result"))

    @bp.route('/result')
    def result():
            if "id" not in session:
                return redirect(url_for("hordes_fv_sniffer.index"))
            task_id = session["id"]
            if task_id not in bp.params:
                return redirect(url_for("hordes_fv_sniffer.index"))
            if executor.futures.done(task_id):
                future = executor.futures.pop(task_id)
                bp.params[task_id]['filename'] = future.result()
                bp.params[task_id]["finished"] = True
            if "finished" in bp.params[task_id] and bp.params[task_id]["finished"]:
                return send_file(bp.params[task_id]['filename'].split("/", 1)[1], as_attachment=True)
            return render_template("load_page.html", css_url=url_for("hordes_fv_sniffer.static", filename="css/main.css"), js_url=url_for("hordes_fv_sniffer.static", filename="js/main.js"))

    @bp.route('/status')
    def status():
        if "id" not in session:
            return redirect(url_for("hordes_fv_sniffer.index"))
        task_id = session["id"]
        if executor.futures.done(task_id):
            future = executor.futures.pop(task_id)
            bp.params[task_id]["status"] = future.result()
        return jsonify(bp.params[task_id])
       

    app = Flask(__name__, instance_relative_config=True)
    app.register_blueprint(bp, url_prefix="/hordes_fv_sniffer")
    app.config['EXECUTOR_TYPE'] = 'thread'
    app.config['EXECUTOR_MAX_WORKERS'] = 5
    executor = Executor(app)
    app.app_context()
    app.config.from_mapping(SECRET_KEY='dev')
    app.params = {}
    print(app.url_map)

    if test_config is None:
        app.config.from_pyfile('config.py', silent = False)
    else:
        app.config.from_mapping(test_config)

    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    @executor.job
    def mock_test_func(login, password):
        app.params["status"] = "Step 1"
        sleep(5)
        app.params["status"] = "Step 2"
        sleep(4)
        app.params["status"] = "Almost Done"
        sleep(3)
        return "This is my result"

    return app
