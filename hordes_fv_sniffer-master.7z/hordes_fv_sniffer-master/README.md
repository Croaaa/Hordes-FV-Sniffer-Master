Install
===

1. Clone
2. Create a venv and install dependencies (requirements.txt)
3. Copy the file `hordes_fv_sniffer.service` in `/etc/systemd/system/hordes_fv_sniffer.service`
4. Start and enable the service: `sudo systemctl start hordes_fv_sniffer` and `sudo systemctl enable hordes_fv_sniffer` (check the status with `sudo systemctl status hordes_fv_sniffer`
5. Configure your web server to proxypass to the socket created in `path/to/cloned/directory/hordes_fv_sniffer.sock`
    Ex (for apache, in a virtualhost):
    ```
   	SSLProxyEngine On
        ProxyPreserveHost On
        ProxyRequests off
        ProxyPass /hordes_fv_sniffer unix:/path/to/cloned/directory/hordes_fv_sniffer.sock|http://localhost/hordes_fv_sniffer
        ProxyPassReverse /hordes_fv_sniffer unix:/path/to/cloned/directory/hordes_fv_sniffer.sock|http://localhost/hordes_fv_sniffer
    ```
6. It should work!
